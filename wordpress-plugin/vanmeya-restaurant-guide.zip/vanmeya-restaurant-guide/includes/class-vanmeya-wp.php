<?php
if (!defined('ABSPATH')) { exit; }

/** Download queue stored in a WordPress database table. Same methods as Vanmeya_Store_Memory. */
class Vanmeya_Store_Wpdb {
    private $t;
    public function __construct() { global $wpdb; $this->t = $wpdb->prefix . 'vanmeya_queue'; }
    public function table() { return $this->t; }
    public function reset() { global $wpdb; $wpdb->query("TRUNCATE TABLE {$this->t}"); }
    public function add($folder, $idx, $url) {
        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "INSERT INTO {$this->t} (folder, idx, url, status, tries) VALUES (%s, %d, %s, 'pending', 0)
             ON DUPLICATE KEY UPDATE status = IF(url = VALUES(url) AND status = 'done', 'done', 'pending'), tries = IF(url = VALUES(url) AND status = 'done', tries, 0), url = VALUES(url)",
            $folder, $idx, $url));
    }
    public function take($n, $max_tries) {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, folder, idx, url, tries FROM {$this->t} WHERE status = 'pending' AND tries < %d ORDER BY tries, id LIMIT %d", $max_tries, $n), ARRAY_A);
        foreach ($rows as &$r) { $r['place_id'] = $r['folder']; $r['id'] = (int)$r['id']; $r['idx'] = (int)$r['idx']; $r['tries'] = (int)$r['tries']; }
        return $rows;
    }
    public function finish($id, $status, $bump, $note = '') {
        global $wpdb;
        $wpdb->query($wpdb->prepare("UPDATE {$this->t} SET status = %s, tries = tries + %d, note = %s WHERE id = %d", $status, $bump ? 1 : 0, $note, $id));
    }
    public function reasons() {
        global $wpdb;
        $out = [];
        foreach ($wpdb->get_results("SELECT note, COUNT(*) n FROM {$this->t} WHERE status = 'failed' GROUP BY note ORDER BY n DESC", ARRAY_A) as $r) { $out[$r['note'] === '' ? 'unknown' : $r['note']] = (int)$r['n']; }
        return $out;
    }
    public function counts() {
        global $wpdb;
        $c = ['pending' => 0, 'done' => 0, 'failed' => 0];
        foreach ($wpdb->get_results("SELECT status, COUNT(*) n FROM {$this->t} GROUP BY status", ARRAY_A) as $r) { $c[$r['status']] = (int)$r['n']; }
        return $c;
    }
    public function retry_failed() { global $wpdb; return $wpdb->query("UPDATE {$this->t} SET status = 'pending', tries = 0 WHERE status = 'failed'"); }
    public function get($id) { global $wpdb; $r = $wpdb->get_row($wpdb->prepare("SELECT id, folder, idx, url, tries FROM {$this->t} WHERE id = %d", $id), ARRAY_A); if ($r) { $r['place_id'] = $r['folder']; $r['id'] = (int)$r['id']; $r['idx'] = (int)$r['idx']; } return $r; }
    public function browser_take($n) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT id, url FROM {$this->t} WHERE status IN ('pending','failed') AND note NOT LIKE 'browser%%' ORDER BY id LIMIT %d", $n), ARRAY_A); }
    public function failed_sample($n = 40) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT folder, idx, url FROM {$this->t} WHERE status = 'failed' ORDER BY id LIMIT %d", $n), ARRAY_A); }
}

class Vanmeya_WP {
    const CAP = 'manage_options';

    public static function init() {
        if (get_option('vanmeya_db') !== '4') { add_action('init', function () { self::activate(); update_option('vanmeya_db', '4', false); }, 1); }
        Vanmeya_Editor_Admin::init();
        Vanmeya_Seo_Admin::init();
        add_action('init', [__CLASS__, 'serve_site'], 0);
        add_action('template_redirect', [__CLASS__, 'serve_404'], 0);
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_post_vanmeya_csv', [__CLASS__, 'handle_csv']);
        add_action('admin_post_vanmeya_zip', [__CLASS__, 'handle_zip']);
        add_action('admin_post_vanmeya_settings', [__CLASS__, 'handle_settings']);
        add_action('admin_post_vanmeya_test', [__CLASS__, 'handle_test']);
        add_action('admin_post_vanmeya_retry', [__CLASS__, 'handle_retry']);
        add_action('wp_ajax_vanmeya_step', [__CLASS__, 'ajax_step']);
        add_action('wp_ajax_vanmeya_chunk', [__CLASS__, 'ajax_chunk']);
        add_action('wp_ajax_vanmeya_unzip', [__CLASS__, 'ajax_unzip']);
        add_action('wp_ajax_vanmeya_btake', [__CLASS__, 'ajax_btake']);
        add_action('wp_ajax_vanmeya_bput', [__CLASS__, 'ajax_bput']);
        add_filter('cron_schedules', function ($s) { $s['vanmeya_minute'] = ['interval' => 60, 'display' => 'Every minute']; return $s; });
        add_action('vanmeya_cron', [__CLASS__, 'cron']);
    }

    /* ---------- paths ---------- */
    public static function base_dir() { $u = wp_upload_dir(); return trailingslashit($u['basedir']) . 'vanmeya'; }
    public static function photo_dir() { return self::base_dir() . '/photos'; }
    public static function site_dir() { return self::base_dir() . '/site'; }
    public static function incoming() { return self::base_dir() . '/incoming'; }
    public static function photo_base_url_path() { $u = wp_upload_dir(); return rtrim((string)wp_parse_url($u['baseurl'], PHP_URL_PATH), '/') . '/vanmeya/photos'; }
    public static function opt($k, $d = '') { $o = get_option('vanmeya_opts', []); return isset($o[$k]) ? $o[$k] : $d; }
    public static function set_opt($k, $v) { $o = get_option('vanmeya_opts', []); $o[$k] = $v; update_option('vanmeya_opts', $o, false); }
    public static function images() { return new Vanmeya_Images(self::photo_dir(), new Vanmeya_Store_Wpdb()); }

    /* ---------- activate ---------- */
    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $t = $wpdb->prefix . 'vanmeya_queue';
        dbDelta("CREATE TABLE $t (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            folder VARCHAR(190) NOT NULL,
            idx SMALLINT UNSIGNED NOT NULL,
            url TEXT NOT NULL,
            status VARCHAR(10) NOT NULL DEFAULT 'pending',
            tries TINYINT UNSIGNED NOT NULL DEFAULT 0,
            note VARCHAR(40) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY photo (folder, idx),
            KEY status (status)
        ) " . $wpdb->get_charset_collate() . ";");
        Vanmeya_Editor_Admin::install();
        Vanmeya_Seo_Admin::install();
        foreach ([self::base_dir(), self::photo_dir(), self::incoming()] as $d) { wp_mkdir_p($d); }
        @file_put_contents(self::base_dir() . '/index.html', '');           // no folder listing
        @file_put_contents(self::incoming() . '/.htaccess', "Require all denied\nDeny from all\n");
        if (self::opt('noindex', null) === null) self::set_opt('noindex', 1); // staging stays hidden from Google until you switch it off
    }
    public static function deactivate() { wp_clear_scheduled_hook('vanmeya_cron'); }

    /* ---------- serving the built site ---------- */
    private static $mime = ['html' => 'text/html; charset=utf-8', 'css' => 'text/css; charset=utf-8', 'js' => 'application/javascript; charset=utf-8',
        'json' => 'application/json; charset=utf-8', 'xml' => 'application/xml; charset=utf-8', 'txt' => 'text/plain; charset=utf-8',
        'svg' => 'image/svg+xml', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp', 'ico' => 'image/x-icon',
        'woff2' => 'font/woff2', 'woff' => 'font/woff'];

    private static function request_path() {
        $p = rawurldecode((string)wp_parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH));
        $home = rtrim((string)wp_parse_url(home_url(), PHP_URL_PATH), '/');
        if ($home !== '' && strpos($p, $home) === 0) $p = substr($p, strlen($home));
        return $p === '' ? '/' : $p;
    }

    private static function send_headers($ctype, $path, $mtime, $html) {
        header('Content-Type: ' . $ctype);
        header('Cache-Control: public, max-age=' . ($html ? 300 : 604800));
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
        if (self::opt('noindex', 1)) header('X-Robots-Tag: noindex, nofollow');
    }

    public static function serve_site() {
        if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX) || (defined('REST_REQUEST') && REST_REQUEST)) return;
        if (!is_dir(self::site_dir()) || !is_file(self::site_dir() . '/index.html')) return;
        $p = self::request_path();
        if (strpos($p, '..') !== false || preg_match('#^/(wp-|xmlrpc)#', $p)) return;
        $key0 = trim($p, '/');
        if ($key0 !== '' && class_exists('Vanmeya_Seo_Admin')) {
            $rd = Vanmeya_Seo_Admin::redirect_for($key0);
            if ($rd) { wp_redirect(preg_match('#^https?://#i', $rd['target']) ? $rd['target'] : home_url($rd['target']), (int)$rd['code']); exit; }
        }
        if ($p === '/robots.txt') {
            header('Content-Type: text/plain; charset=utf-8');
            $seo = Vanmeya_Seo_Admin::settings();
            if (self::opt('noindex', 1)) echo "User-agent: *\nDisallow: /\n";
            elseif (!empty($seo['robots'])) echo $seo['robots'];
            else echo "User-agent: *\nAllow: /\n\nSitemap: " . home_url('/sitemap.xml') . "\n";
            exit;
        }
        if ($p === '/sitemap.xml' && is_file(self::site_dir() . '/sitemap.xml')) {
            global $wpdb; $drop = []; $add = [];
            foreach ($wpdb->get_results("SELECT path, data, custom FROM " . Vanmeya_Editor_Admin::table(), ARRAY_A) as $r) {
                $d = json_decode($r['data'], true); if (!is_array($d)) continue;
                if (!empty($d['noindex'])) $drop[] = $r['path'];
                elseif ((int)$r['custom']) $add[] = home_url('/' . $r['path'] . '/');
            }
            header('Content-Type: application/xml; charset=utf-8');
            if (self::opt('noindex', 1)) header('X-Robots-Tag: noindex');
            echo Vanmeya_Seo_Core::filter_sitemap((string)file_get_contents(self::site_dir() . '/sitemap.xml'), $drop, $add); exit;
        }
        $root = realpath(self::site_dir());
        $rel = ltrim($p, '/');
        $file = $root . '/' . $rel;
        if ($rel === '' || substr($p, -1) === '/') $file = rtrim($file, '/') . '/index.html';
        elseif (is_dir($file)) { wp_redirect(home_url($p . '/'), 301); exit; }
        if ($rel === 'vm-pages.json' || $rel === '_vm_shell.html') return;
        $real = realpath($file);
        $key = trim($p, '/');
        if (!$real || strpos($real, $root . DIRECTORY_SEPARATOR) !== 0 || !is_file($real)) {
            $c = class_exists('Vanmeya_Editor_Admin') && $key !== '' ? Vanmeya_Editor_Admin::get($key) : null;     // a page added in the admin
            if ($c && $c['custom'] && is_file($root . '/_vm_shell.html')) {
                status_header(200);
                self::send_headers(self::$mime['html'], $root . '/_vm_shell.html', time(), true);
                header('Cache-Control: no-cache');
                echo Vanmeya_Seo_Core::decorate(Vanmeya_Editor::from_shell((string)file_get_contents($root . '/_vm_shell.html'), $c['data'], home_url('/' . $key . '/')), Vanmeya_Seo_Admin::settings(), $c['data']);
                exit;
            }
            return;   // not ours: WordPress carries on
        }
        $ext = strtolower(pathinfo($real, PATHINFO_EXTENSION));
        $ctype = isset(self::$mime[$ext]) ? self::$mime[$ext] : 'application/octet-stream';
        $mtime = filemtime($real);
        if ($ext === 'html' && class_exists('Vanmeya_Editor_Admin')) {
            $relf = substr($real, strlen($root) + 1);
            $pk = $relf === 'index.html' ? '' : (basename($relf) === 'index.html' ? str_replace(DIRECTORY_SEPARATOR, '/', dirname($relf)) : null);
            if ($pk !== null) {
                $c = Vanmeya_Editor_Admin::get($pk);
                $html = (string)file_get_contents($real);
                if ($c) $html = Vanmeya_Editor::apply($html, $c['data']);
                $html = Vanmeya_Seo_Core::decorate($html, Vanmeya_Seo_Admin::settings(), $c ? $c['data'] : []);
                self::send_headers($ctype, $real, $mtime, true);
                header('Cache-Control: no-cache');
                header_remove('Last-Modified');
                echo $html;
                exit;
            }
        }
        if (isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) && strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) >= $mtime) { status_header(304); exit; }
        self::send_headers($ctype, $real, $mtime, $ext === 'html');
        header('Content-Length: ' . filesize($real));
        readfile($real);
        exit;
    }

    public static function serve_404() {
        if (!is_404()) return;
        if (is_file(self::site_dir() . '/index.html') && class_exists('Vanmeya_Seo_Admin')) Vanmeya_Seo_Admin::log_404(trim(self::request_path(), '/'));
        $f = self::site_dir() . '/404.html';
        if (!is_file($f)) return;
        status_header(404);
        self::send_headers(self::$mime['html'], $f, filemtime($f), true);
        readfile($f);
        exit;
    }

    /* ---------- admin screen ---------- */
    public static function menu() {
        add_menu_page('Vanmeya', 'Vanmeya', self::CAP, 'vanmeya', [__CLASS__, 'page'], 'dashicons-store', 58);
        add_submenu_page('vanmeya', 'Start here', 'Start here', self::CAP, 'vanmeya', [__CLASS__, 'page']);
        add_submenu_page('vanmeya', 'Photos', 'Photos', self::CAP, 'vanmeya-photos', [__CLASS__, 'page']);
        add_submenu_page('vanmeya', 'Website', 'Website', self::CAP, 'vanmeya-website', [__CLASS__, 'page']);
        add_action('admin_menu', function () { add_submenu_page('vanmeya', 'Settings', 'Settings', self::CAP, 'vanmeya-settings', [__CLASS__, 'page']); }, 99);
    }

    private static function dashboard_extras($c, $installed) {
        $seo = Vanmeya_Seo_Admin::settings();
        $mark = function ($ok) { return $ok ? '<span style="color:#1a7f37">&#10004;</span>' : '<span style="color:#b32d2e">&#9679;</span>'; };
        $link = function ($page, $label, $extra = []) { return '<a href="' . esc_url(add_query_arg(array_merge(['page' => $page], $extra), admin_url('admin.php'))) . '">' . esc_html($label) . '</a>'; };
        $hidden = (int)self::opt('noindex', 1);
        echo '<div style="background:#fff;border:1px solid #c3c4c7;padding:12px 16px;max-width:820px;margin:14px 0"><strong>Your SEO</strong><br>'
            . $mark(!$hidden) . ' Visible to Google: ' . ($hidden ? '<strong>no, hidden (staging mode).</strong> Change it in ' . $link('vanmeya-settings', 'Settings') . ' when you go live.' : '<strong>yes</strong>') . '<br>'
            . $mark(!empty($seo['gsc'])) . ' Search Console verification: ' . (!empty($seo['gsc']) ? 'added' : 'not added') . ' &middot; ' . $mark(!empty($seo['ga4']) || !empty($seo['gtm'])) . ' Analytics: ' . (!empty($seo['ga4']) || !empty($seo['gtm']) ? 'added' : 'not added') . ' (' . $link('vanmeya-seo', 'set up', ['tab' => 'tracking']) . ')<br>'
            . '&rarr; ' . $link('vanmeya-seo', 'Check my pages for SEO problems') . '</div>';
        echo '<div style="background:#fff;border:1px solid #c3c4c7;padding:12px 16px;max-width:820px;margin:14px 0"><strong>Where do I do what?</strong><ol style="margin:8px 0 0 18px">'
            . '<li>' . $link('vanmeya-photos', 'Photos') . ': upload the images file from GitHub and download the restaurant photos.</li>'
            . '<li>' . $link('vanmeya-website', 'Website') . ': upload the website zip from GitHub. This creates all the pages.</li>'
            . '<li>' . $link('vanmeya-pages', 'Pages & content') . ': find any page, change its text, add extra content, or add a new page.</li>'
            . '<li>' . $link('vanmeya-seo', 'SEO') . ': check problems, edit titles in bulk, set rules, redirects, tracking and robots.txt.</li>'
            . '<li>' . $link('vanmeya-settings', 'Settings') . ': hide or show the site to Google, background downloads.</li></ol>'
            . '<p class="description">New restaurants or new text in the Google Sheets: run the GitHub workflow, then upload again in Photos or Website.</p></div>';
    }

    private static function check_rows() {
        $up = wp_upload_dir();
        $free = @disk_free_space($up['basedir']);
        $rows = [
            ['PHP version', PHP_VERSION, version_compare(PHP_VERSION, '7.4', '>=')],
            ['Image tools (WebP)', Vanmeya_Images::can_make_webp() ? 'ready' : 'missing: ask your host to enable the GD extension with WebP', Vanmeya_Images::can_make_webp()],
            ['Parallel downloads (curl)', function_exists('curl_multi_init') ? 'ready' : 'missing', function_exists('curl_multi_init')],
            ['Zip support', class_exists('ZipArchive') ? 'ready' : 'missing', class_exists('ZipArchive')],
            ['Memory limit', ini_get('memory_limit'), true],
            ['Largest upload', ini_get('upload_max_filesize') . ' (bigger files can be placed in the incoming folder, see below)', true],
            ['Free disk space', $free ? size_format($free) : 'unknown', !$free || $free > 500 * 1048576],
            ['Photo folder writable', wp_is_writable(self::base_dir()) || wp_mkdir_p(self::photo_dir()) ? 'yes' : 'no', wp_is_writable(self::base_dir())],
        ];
        return $rows;
    }

    public static function page() {
        if (!current_user_can(self::CAP)) return;
        $st = new Vanmeya_Store_Wpdb();
        $c = $st->counts();
        $total = max(1, array_sum($c));
        $nonce = wp_create_nonce('vanmeya');
        $installed = is_file(self::site_dir() . '/index.html');
        $msg = isset($_GET['vm']) ? sanitize_text_field(wp_unslash($_GET['vm'])) : '';
        $pg = isset($_GET['page']) ? sanitize_key($_GET['page']) : 'vanmeya';
        $sec = ['vanmeya-photos' => 'photos', 'vanmeya-website' => 'site', 'vanmeya-settings' => 'settings'][$pg] ?? 'dash';
        $titles = ['dash' => 'Vanmeya: start here', 'photos' => 'Photos', 'site' => 'Website', 'settings' => 'Settings'];
        echo '<div class="wrap"><h1>' . esc_html($titles[$sec]) . '</h1>';
        if ($msg) echo '<div class="notice notice-info"><p>' . esc_html($msg) . '</p></div>';

        if ($sec !== 'dash') echo '<p id="vm-live" style="font-weight:600"></p>';
        $pages = (int)self::opt('html_pages', 0);
        if ($sec === 'dash') {
        $mark = function ($ok) { return $ok ? '<span style="color:#1a7f37">&#10004;</span>' : '<span style="color:#b32d2e">&#9679;</span>'; };
        echo '<div style="background:#fff;border:1px solid #c3c4c7;border-left:4px solid #2271b1;padding:12px 16px;max-width:820px;margin:14px 0"><strong>Status</strong><br>'
            . $mark($c['pending'] === 0 && $c['done'] > 0) . ' Photos: <strong>' . number_format_i18n($c['done']) . '</strong> downloaded, ' . number_format_i18n($c['pending']) . ' waiting, ' . number_format_i18n($c['failed']) . ' failed (failed are mostly logos or tiny images that are skipped on purpose)<br>'
            . $mark($installed) . ' Website pages: ' . ($installed ? '<strong>installed</strong>' . ($pages ? ', ' . number_format_i18n($pages) . ' pages' : '') . ' &middot; <a href="' . esc_url(home_url('/')) . '" target="_blank">open the website</a>' : '<strong>not installed yet</strong> (see step 3)') . '<br>'
            . '<span id="vm-live" style="display:block;margin-top:6px;color:#1d2327"></span></div>';
        self::dashboard_extras($c, $installed);
        echo '<h2>Check this hosting</h2><table class="widefat striped" style="max-width:820px"><tbody>';
        foreach (self::check_rows() as $r) echo '<tr><td style="width:240px"><strong>' . esc_html($r[0]) . '</strong></td><td>' . esc_html($r[1]) . '</td><td style="width:30px">' . ($r[2] ? '&#10004;' : '&#9888;') . '</td></tr>';
        echo '</tbody></table>';

        }
        if ($sec === 'photos') {
        echo '<h2>Photos</h2><p>Upload the <strong>images_database.csv</strong> file from the GitHub run. The plugin downloads each restaurant\'s photos into its own folder: <code>' . esc_html(self::photo_base_url_path()) . '/&lt;place_id&gt;/1.webp</code>, 2.webp and so on.</p>';
        echo '<form method="post" enctype="multipart/form-data" data-chunk="csv" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="vanmeya_csv"><input type="hidden" name="_wpnonce" value="' . esc_attr($nonce) . '">';
        echo '<input type="file" name="csv" accept=".csv"> <button class="button button-primary">Upload and queue photos</button> ';
        echo '<label style="margin-left:12px"><input type="checkbox" name="use_incoming" value="1"> use <code>incoming/images_database.csv</code> instead (for very large files)</label></form>';

        echo '<div style="max-width:820px;margin:14px 0"><div style="background:#e5e5e5;height:18px;border-radius:9px;overflow:hidden"><div id="vm-bar" style="background:#1d2327;height:100%;width:' . esc_attr(round(100 * $c['done'] / $total)) . '%"></div></div>';
        echo '<p id="vm-text">Downloaded <strong id="vm-done">' . (int)$c['done'] . '</strong> &middot; waiting <strong id="vm-pending">' . (int)$c['pending'] . '</strong> &middot; failed <strong id="vm-failed">' . (int)$c['failed'] . '</strong></p>';
        echo '<button class="button button-primary" id="vm-start">Start downloading</button> <button class="button" id="vm-stop" disabled>Pause</button> ';
        echo '<span id="vm-note" style="margin-left:10px;color:#555">Keep this page open while it runs. You can pause and continue at any time.</span></div>';
        echo '<p style="margin:12px 0"><button class="button" id="vm-bstart">Download with my own browser instead</button> <span id="vm-bnote" class="description">Use this if the hosting cannot reach Google: your computer fetches the photos and sends them to the hosting. Keep this page open.</span></p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:12px 0"><input type="hidden" name="action" value="vanmeya_test"><input type="hidden" name="_wpnonce" value="' . esc_attr($nonce) . '"><button class="button">Test the connection to Google photos</button> <span class="description">Tries one photo link and tells you exactly what happens.</span></form>';
        if ($c['failed']) {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="vanmeya_retry"><input type="hidden" name="_wpnonce" value="' . esc_attr($nonce) . '"><button class="button">Try the ' . (int)$c['failed'] . ' failed photos again</button> <span class="description">Failed photos are usually links that expired. Upload a newer images database to replace them.</span></form>';
            $why = $st->reasons();
            echo '<p><strong>Why photos failed:</strong> ';
            foreach ($why as $k => $n) echo '<code>' . esc_html($k) . '</code> ' . (int)$n . ' &nbsp; ';
            echo '</p><details style="margin:10px 0"><summary>Show some failed photos</summary><ul>';
            foreach ($st->failed_sample() as $f) echo '<li><code>' . esc_html($f['folder'] . ' #' . $f['idx']) . '</code> ' . esc_html(wp_html_excerpt($f['url'], 90, '...')) . '</li>';
            echo '</ul></details>';
        }

        }
        if ($sec === 'site') {
        echo '<h2>Website pages</h2><p>Upload <strong>site-for-hosting.zip</strong> from the "hosting-site" GitHub run. When it is installed, the plugin shows the guide at the root of this site (<code>' . esc_html(home_url('/')) . '</code>).</p>';
        echo '<p>The site builder needs this photo path: <code>' . esc_html(self::photo_base_url_path()) . '</code></p>';
        echo '<p>' . ($installed ? '<strong>Installed.</strong> Last updated ' . esc_html(date_i18n('j M Y, H:i', filemtime(self::site_dir() . '/index.html'))) . '. <a href="' . esc_url(home_url('/')) . '" target="_blank">Open the website</a>' : 'Not installed yet.') . '</p>';
        echo '<form method="post" enctype="multipart/form-data" data-chunk="zip" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="vanmeya_zip"><input type="hidden" name="_wpnonce" value="' . esc_attr($nonce) . '">';
        echo '<input type="file" name="zip" accept=".zip"> <button class="button button-primary">Upload and install</button> ';
        echo '<label style="margin-left:12px"><input type="checkbox" name="use_incoming" value="1"> use <code>incoming/site-for-hosting.zip</code> instead</label></form>';
        echo '<p class="description">Large files: put them in <code>' . esc_html(self::incoming()) . '</code> with your hosting file manager, then tick the box.</p>';

        }
        if ($sec === 'settings') {
        echo '<h2>Settings</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="vanmeya_settings"><input type="hidden" name="_wpnonce" value="' . esc_attr($nonce) . '">';
        echo '<p><label><input type="checkbox" name="noindex" value="1" ' . checked(self::opt('noindex', 1), 1, false) . '> <strong>Hide this site from Google</strong> (keep ticked on a staging site; untick when you go live)</label></p>';
        echo '<p><label><input type="checkbox" name="background" value="1" ' . checked(self::opt('background', 0), 1, false) . '> Keep downloading in the background when this page is closed (needs site visits or a server cron job)</label></p>';
        echo '<p><button class="button">Save settings</button></p></form>';

        }
        $ajax = esc_url(admin_url('admin-ajax.php'));
        echo '<script>(function(){var run=false,btn=document.getElementById("vm-start"),stop=document.getElementById("vm-stop"),note=document.getElementById("vm-note");if(!btn)return;
        function upd(c){var t=c.done+c.pending+c.failed||1;document.getElementById("vm-done").textContent=c.done;document.getElementById("vm-pending").textContent=c.pending;document.getElementById("vm-failed").textContent=c.failed;document.getElementById("vm-bar").style.width=Math.round(100*c.done/t)+"%";}
        function loop(){if(!run)return;var f=new FormData();f.append("action","vanmeya_step");f.append("_wpnonce","' . esc_js($nonce) . '");
        fetch("' . $ajax . '",{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(j){if(!j.success){note.textContent="Stopped: "+(j.data||"error");run=false;btn.disabled=false;stop.disabled=true;return;}
        upd(j.data.counts);if(j.data.counts.pending===0){note.textContent="Finished.";run=false;btn.disabled=false;stop.disabled=true;return;}note.textContent="Working...";setTimeout(loop,200);}).catch(function(){note.textContent="Connection problem, trying again...";setTimeout(loop,3000);});}
        btn.onclick=function(){run=true;btn.disabled=true;stop.disabled=false;loop();};stop.onclick=function(){run=false;btn.disabled=false;stop.disabled=true;note.textContent="Paused.";};})();</script>';

        echo '<script>(function(){var AJ="' . $ajax . '",NC="' . esc_js($nonce) . '";
        function post(a,f){f.append("action",a);f.append("_wpnonce",NC);return fetch(AJ,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json();});}
        document.querySelectorAll("form[data-chunk]").forEach(function(fm){fm.addEventListener("submit",function(e){
          var inp=fm.querySelector("input[type=file]"),file=inp&&inp.files[0];if(!file||fm.dataset.sent)return;e.preventDefault();
          var live=document.getElementById("vm-live");function say(m,bad){live.textContent=m;live.style.color=bad?"#b32d2e":"#1d2327";live.style.fontWeight=bad?"600":"400";}
          var kind=fm.dataset.chunk,size=1048576,total=Math.ceil(file.size/size),i=0,btn=fm.querySelector("button");btn.disabled=true;
          function next(){if(i>=total){inp.value="";if(kind==="zip"){install();return;}fm.dataset.sent=1;fm.querySelector("input[name=use_incoming]").checked=true;btn.textContent="Queueing, please wait...";fm.submit();return;}
            var f=new FormData();f.append("kind",kind);f.append("index",i);f.append("piece",file.slice(i*size,(i+1)*size),"p");
            btn.textContent="Uploading "+Math.round(100*i/total)+"%";say("Uploading "+file.name+": "+Math.round(100*i/total)+"% (keep this page open)");
            post("vanmeya_chunk",f).then(function(j){if(!j.success){say("Upload stopped: "+j.data,1);btn.disabled=false;btn.textContent="Try again";return;}i++;next();}).catch(function(){say("Connection hiccup, retrying...");setTimeout(next,2000);});}
          function fail(m){say("Install stopped: "+m,1);btn.disabled=false;btn.textContent="Try again";}
          function install(){say("Upload finished. Checking the zip...");var f=new FormData();f.append("phase","start");post("vanmeya_unzip",f).then(function(j){if(!j.success)return fail(j.data);step(0,j.data.total);}).catch(function(e){fail("no answer from the server ("+e+")");});}
          function step(pos,tot){var f=new FormData();f.append("phase","run");f.append("pos",pos);btn.textContent="Unpacking "+Math.round(100*pos/tot)+"%";say("Unpacking website files: "+pos+" of "+tot+" (keep this page open)");
            if(pos>=tot){var g=new FormData();g.append("phase","finish");post("vanmeya_unzip",g).then(function(j){if(!j.success)return fail(j.data);say("Done. The website is installed: "+j.data.pages+" pages. Reloading...");setTimeout(function(){location.href=location.pathname+"?page=vanmeya-website";},1500);}).catch(function(e){fail(""+e);});return;}
            post("vanmeya_unzip",f).then(function(j){if(!j.success)return fail(j.data);step(j.data.pos,j.data.total);}).catch(function(){say("Connection hiccup, retrying...");setTimeout(function(){step(pos,tot);},2500);});}
          next();});});
        var bb=document.getElementById("vm-bstart"),bn=document.getElementById("vm-bnote"),brun=false;
        function toWebp(url){return fetch(url,{mode:"cors",referrerPolicy:"no-referrer"}).then(function(r){if(!r.ok)throw new Error("http_"+r.status);return r.blob();}).then(function(b){return createImageBitmap(b);}).then(function(bm){var w=bm.width,h=bm.height;if(w<200||h<200)throw new Error("too_small");var s=w>800?800/w:1,cv=document.createElement("canvas");cv.width=Math.round(w*s);cv.height=Math.round(h*s);cv.getContext("2d").drawImage(bm,0,0,cv.width,cv.height);return new Promise(function(ok,no){cv.toBlob(function(x){x?ok(x):no(new Error("encode"));},"image/webp",0.78);});});}
        function one(it){return toWebp(it.url).then(function(b){var f=new FormData();f.append("id",it.id);f.append("img",b,"x.webp");return post("vanmeya_bput",f);}).catch(function(err){var f=new FormData();f.append("id",it.id);var m=(err&&err.message)||"error";f.append("fail",m==="Failed to fetch"?"blocked":m);return post("vanmeya_bput",f);});}
        function bloop(){if(!brun)return;post("vanmeya_btake",new FormData()).then(function(j){if(!j.success||!j.data.items.length){bn.textContent="Finished (or nothing left to try).";brun=false;bb.textContent="Download with my own browser instead";return;}
          Promise.all(j.data.items.map(one)).then(function(r){var c=r[r.length-1]&&r[r.length-1].data&&r[r.length-1].data.counts;if(c)bn.textContent="Downloaded "+c.done+", waiting "+c.pending+", failed "+c.failed+" (keep this page open)";bloop();});}).catch(function(){setTimeout(bloop,3000);});}
        if(bb)bb.onclick=function(){if(brun){brun=false;bb.textContent="Download with my own browser instead";bn.textContent="Paused.";return;}brun=true;bb.textContent="Pause browser download";bn.textContent="Working...";bloop();};})();</script>';
        echo '</div>';
    }

    /* ---------- actions ---------- */
    private static function back($msg) {
        $to = ['vanmeya_csv' => 'vanmeya-photos', 'vanmeya_retry' => 'vanmeya-photos', 'vanmeya_test' => 'vanmeya-photos', 'vanmeya_zip' => 'vanmeya-website', 'vanmeya_settings' => 'vanmeya-settings'];
        $act = isset($_POST['action']) ? $_POST['action'] : '';
        wp_safe_redirect(add_query_arg(['page' => isset($to[$act]) ? $to[$act] : 'vanmeya', 'vm' => rawurlencode($msg)], admin_url('admin.php'))); exit;
    }
    private static function guard() { if (!current_user_can(self::CAP) || !wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'vanmeya')) wp_die('Not allowed.'); }

    private static function incoming_or_upload($field, $fixed_name) {
        if (!empty($_POST['use_incoming'])) {
            $p = self::incoming() . '/' . $fixed_name;
            return is_file($p) ? $p : null;
        }
        if (!empty($_FILES[$field]['tmp_name']) && is_uploaded_file($_FILES[$field]['tmp_name']) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) return $_FILES[$field]['tmp_name'];
        return null;
    }

    public static function handle_csv() {
        self::guard();
        wp_mkdir_p(self::photo_dir());
        $path = self::incoming_or_upload('csv', 'images_database.csv');
        if (!$path) self::back('No file received. If the file is large, use the incoming folder option.');
        @set_time_limit(300);
        list($rows, $err) = Vanmeya_Csv::read($path, 10);
        if ($err) self::back($err);
        $n = self::images()->enqueue($rows);
        if ($n === 0 && count($rows) > 0) self::back('Read ' . count($rows) . ' restaurants. Every photo in this file is already downloaded.');
        self::back('Read ' . count($rows) . ' restaurants and queued ' . number_format_i18n($n) . ' photos. Press "Start downloading".');
    }

    public static function handle_test() {
        self::guard();
        global $wpdb; $t = $wpdb->prefix . 'vanmeya_queue';
        $url = $wpdb->get_var("SELECT url FROM $t ORDER BY (status = 'pending') DESC, id DESC LIMIT 1");
        $out = $url ? 'Photo link: ' . Vanmeya_Images::diagnose($url) : 'No photo links yet, upload the images database first.';
        $out .= ' | Google home page: ' . Vanmeya_Images::diagnose('https://www.google.com/');
        $out .= ' | Another image host: ' . Vanmeya_Images::diagnose('https://www.gstatic.com/images/branding/product/1x/googleg_48dp.png');
        self::back($out);
    }
    public static function handle_retry() { self::guard(); $n = (new Vanmeya_Store_Wpdb())->retry_failed(); self::back("Queued $n photos again."); }

    public static function handle_settings() {
        self::guard();
        self::set_opt('noindex', empty($_POST['noindex']) ? 0 : 1);
        self::set_opt('background', empty($_POST['background']) ? 0 : 1);
        if (self::opt('background', 0)) { if (!wp_next_scheduled('vanmeya_cron')) wp_schedule_event(time() + 60, 'vanmeya_minute', 'vanmeya_cron'); }
        else wp_clear_scheduled_hook('vanmeya_cron');
        self::back('Settings saved.');
    }

    public static function ajax_step() {
        if (!current_user_can(self::CAP) || !wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'vanmeya')) wp_send_json_error('Not allowed.');
        if (!Vanmeya_Images::can_make_webp()) wp_send_json_error('This hosting cannot create WebP images (GD with WebP is missing).');
        $res = self::run_for(15);
        wp_send_json_success(['counts' => (new Vanmeya_Store_Wpdb())->counts(), 'step' => $res]);
    }

    /** Browser upload in small pieces, so the hosting's upload size limit does not matter. */
    public static function ajax_chunk() {
        if (!current_user_can(self::CAP) || !wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'vanmeya')) wp_send_json_error('Not allowed.');
        $kind = isset($_POST['kind']) ? $_POST['kind'] : '';
        $names = ['csv' => 'images_database.csv', 'zip' => 'site-for-hosting.zip'];
        if (!isset($names[$kind])) wp_send_json_error('Unknown file type.');
        if (empty($_FILES['piece']['tmp_name']) || !is_uploaded_file($_FILES['piece']['tmp_name'])) wp_send_json_error('The piece did not arrive.');
        $dir = self::incoming(); wp_mkdir_p($dir);
        $dest = $dir . '/' . $names[$kind];
        $i = (int)$_POST['index'];
        $data = file_get_contents($_FILES['piece']['tmp_name']);
        if (@file_put_contents($dest, $data, $i === 0 ? 0 : FILE_APPEND) === false) wp_send_json_error('Could not write the file (disk full?).');
        wp_send_json_success(['size' => filesize($dest)]);
    }

    /** Install the site zip in small steps, so a short time limit on the hosting cannot stop it. */
    public static function ajax_unzip() {
        if (!current_user_can(self::CAP) || !wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'vanmeya')) wp_send_json_error('Not allowed.');
        if (!class_exists('ZipArchive')) wp_send_json_error('This hosting has no zip support.');
        @set_time_limit(120);
        register_shutdown_function(function () { $e = error_get_last(); if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) { @header('Content-Type: application/json'); echo json_encode(['success' => false, 'data' => 'The server stopped: ' . $e['message']]); } });
        $base = self::base_dir(); $new = $base . '/site_new'; $work = $base . '/work.zip'; $phase = isset($_POST['phase']) ? $_POST['phase'] : '';
        if ($phase === 'start') {
            $src = self::incoming() . '/site-for-hosting.zip';
            if (!is_file($src)) wp_send_json_error('The uploaded file is missing on the hosting. Upload it again.');
            $zip = new ZipArchive();
            if ($zip->open($src) !== true) wp_send_json_error('That file is not a valid zip (the upload may be incomplete).');
            for ($d = 0; $d < 2 && $zip->locateName('index.html') === false; $d++) {
                $inner = false;
                for ($i = 0; $i < $zip->numFiles; $i++) if (substr((string)$zip->getNameIndex($i), -4) === '.zip') { $inner = $i; break; }
                if ($inner === false) break;
                if (!@file_put_contents($base . '/inner.zip', $zip->getFromIndex($inner))) { $zip->close(); wp_send_json_error('Could not unpack the zip inside the zip (disk full?).'); }
                $zip->close(); $zip = new ZipArchive();
                if ($zip->open($base . '/inner.zip') !== true) wp_send_json_error('The zip inside the downloaded zip is not valid.');
            }
            $total = $zip->numFiles;
            if ($zip->locateName('index.html') === false) { $zip->close(); wp_send_json_error('This zip has no index.html at its top level. It has ' . $total . ' entries; first one: ' . (string)$zip->getNameIndex(0) . '. Use site-for-hosting.zip from the hosting-site run.'); }
            for ($i = 0; $i < $total; $i++) { $n = (string)$zip->getNameIndex($i); if (in_array('..', explode('/', str_replace('\\', '/', $n)), true) || $n === '' || $n[0] === '/' || strpos($n, "\0") !== false || strpos($n, ':') !== false) { $zip->close(); wp_send_json_error('The zip contains an unsafe path and was not installed.'); } }
            $zip->close();
            $from = is_file($base . '/inner.zip') ? $base . '/inner.zip' : $src;
            if (!@copy($from, $work)) wp_send_json_error('Could not copy the zip (disk full?).');
            @unlink($base . '/inner.zip');
            self::rrmdir($new); wp_mkdir_p($new);
            wp_send_json_success(['pos' => 0, 'total' => $total]);
        }
        if ($phase === 'run') {
            $pos = (int)$_POST['pos'];
            $zip = new ZipArchive();
            if (!is_file($work) || $zip->open($work) !== true) wp_send_json_error('The working copy is missing. Start again.');
            $total = $zip->numFiles; $t0 = time();
            while ($pos < $total && time() - $t0 < 12) {
                $names = [];
                for ($i = $pos; $i < min($total, $pos + 200); $i++) $names[] = $zip->getNameIndex($i);
                if (!$zip->extractTo($new, $names)) { $zip->close(); wp_send_json_error('Could not write files at ' . $pos . ' of ' . $total . ' (disk full or file limit reached?).'); }
                $pos += count($names);
            }
            $zip->close();
            wp_send_json_success(['pos' => $pos, 'total' => $total]);
        }
        if ($phase === 'finish') {
            $old = $base . '/site_old'; $cur = self::site_dir();
            if (!is_file($new . '/index.html')) wp_send_json_error('Unpacking did not produce index.html. Start again.');
            self::rrmdir($old);
            if (is_dir($cur)) rename($cur, $old);
            if (!rename($new, $cur)) wp_send_json_error('Could not switch to the new website.');
            self::rrmdir($old); @unlink($work); @unlink(self::incoming() . '/site-for-hosting.zip');
            $html = 0; foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($cur, FilesystemIterator::SKIP_DOTS)) as $f) if (substr($f->getFilename(), -5) === '.html') $html++;
            self::set_opt('html_pages', $html);
            wp_send_json_success(['pages' => $html, 'url' => home_url('/')]);
        }
        wp_send_json_error('Unknown step.');
    }

    /** Photos fetched by the visitor's own browser: hand out links ... */
    public static function ajax_btake() {
        if (!current_user_can(self::CAP) || !wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'vanmeya')) wp_send_json_error('Not allowed.');
        $st = new Vanmeya_Store_Wpdb();
        wp_send_json_success(['items' => $st->browser_take(6), 'counts' => $st->counts()]);
    }

    /** ... and receive the finished picture (or the reason it failed). */
    public static function ajax_bput() {
        if (!current_user_can(self::CAP) || !wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'vanmeya')) wp_send_json_error('Not allowed.');
        $st = new Vanmeya_Store_Wpdb();
        $it = $st->get((int)$_POST['id']);
        if (!$it) wp_send_json_error('Unknown photo.');
        $fail = isset($_POST['fail']) ? substr(sanitize_text_field($_POST['fail']), 0, 40) : '';
        if ($fail !== '' || empty($_FILES['img']['tmp_name']) || !is_uploaded_file($_FILES['img']['tmp_name'])) {
            $st->finish($it['id'], 'failed', true, 'browser_' . ($fail !== '' ? $fail : 'no_file'));
        } else {
            $why = self::images()->save_public($it, file_get_contents($_FILES['img']['tmp_name']));
            $why === '' ? $st->finish($it['id'], 'done', false, '') : $st->finish($it['id'], 'failed', true, 'browser_' . $why);
        }
        wp_send_json_success(['counts' => $st->counts()]);
    }

    private static function run_for($seconds) {
        @set_time_limit($seconds + 30);
        $im = self::images();
        $t0 = time(); $tot = ['ok' => 0, 'failed' => 0, 'retry' => 0, 'taken' => 0, 'net' => 0];
        do {
            $r = $im->step(8);
            foreach ($tot as $k => $_) $tot[$k] += $r[$k];
        } while ($r['taken'] > 0 && time() - $t0 < $seconds);
        return $tot;
    }

    public static function cron() {
        if (!self::opt('background', 0) || !Vanmeya_Images::can_make_webp()) return;
        $c = (new Vanmeya_Store_Wpdb())->counts();
        if ($c['pending'] > 0) self::run_for(25);
    }

    /* ---------- install the site zip ---------- */
    public static function handle_zip() {
        self::guard();
        if (!class_exists('ZipArchive')) self::back('This hosting has no zip support.');
        $path = self::incoming_or_upload('zip', 'site-for-hosting.zip');
        if (!$path) self::back('No file received. If the file is large, use the incoming folder option.');
        @set_time_limit(300);
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) self::back('That file is not a valid zip.');
        $names = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $n = $zip->getNameIndex($i);
            if ($n === false || in_array('..', explode('/', str_replace('\\', '/', $n)), true) || $n[0] === '/' || strpos($n, "\0") !== false || strpos($n, ':') !== false) { $zip->close(); self::back('The zip contains an unsafe path and was not installed.'); }
            $names[] = $n;
        }
        if (!in_array('index.html', $names, true)) { $zip->close(); self::back('This zip has no index.html at its top level. Use site-for-hosting.zip from the hosting-site run.'); }
        $new = self::base_dir() . '/site_new'; $old = self::base_dir() . '/site_old'; $cur = self::site_dir();
        self::rrmdir($new); self::rrmdir($old);
        wp_mkdir_p($new);
        if (!$zip->extractTo($new)) { $zip->close(); self::rrmdir($new); self::back('The zip could not be unpacked (disk full?).'); }
        $zip->close();
        if (is_dir($cur)) rename($cur, $old);
        rename($new, $cur);
        self::rrmdir($old); @unlink(self::base_dir() . '/inner.zip');
        if (!empty($_POST['use_incoming'])) @unlink($path);
        self::back('Website installed: ' . number_format_i18n(count($names)) . ' files.');
    }

    private static function rrmdir($d) {
        if (!is_dir($d)) return;
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $f) {
            $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
        }
        @rmdir($d);
    }
}
